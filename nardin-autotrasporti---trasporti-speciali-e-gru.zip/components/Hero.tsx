
import React from 'react';

interface HeroProps {
  onQuoteClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onQuoteClick }) => {
  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden bg-gray-900">
      {/* Background Image Overlay - Reflecting the Scania Crane in Mountains */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1542663013-14674724c96d?ixlib=rb-4.2.1&auto=format&fit=crop&w=1920&q=80" 
          alt="Nardin Scania Crane in Action" 
          className="w-full h-full object-cover opacity-50 grayscale-[20%]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-gray-900"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <div className="inline-block px-4 py-1 mb-6 bg-orange-600/20 border border-orange-500/50 rounded-full">
          <span className="text-orange-500 font-bold text-xs uppercase tracking-widest">Precisione e Potenza dal 19XX</span>
        </div>
        
        <h1 className="text-5xl md:text-8xl font-black text-white mb-6 uppercase leading-tight italic drop-shadow-2xl">
          NARDIN <span className="text-orange-500">AUTOTRASPORTI</span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-300 mb-10 leading-relaxed font-medium">
          Soluzioni di sollevamento e trasporto eccezionale con flotta all'avanguardia. 
          Specialisti in movimentazioni complesse in contesti difficili.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <button 
            onClick={onQuoteClick}
            className="w-full sm:w-auto px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-xl uppercase tracking-wider"
          >
            Consulenza Tecnica AI
          </button>
          <a 
            href="#progetti" 
            className="w-full sm:w-auto px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg transition-all border border-white/30 backdrop-blur-sm uppercase tracking-wider"
          >
            Guarda la Flotta
          </a>
        </div>
      </div>

      {/* Decorative Bottom Wave/Pattern */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-[0]">
        <svg className="relative block w-[calc(100%+1.3px)] h-[100px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M1200 120L0 120 309.19 0 1200 120z" className="fill-white"></path>
        </svg>
      </div>
    </div>
  );
};

export default Hero;
