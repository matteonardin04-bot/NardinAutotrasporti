
import React from 'react';
import { Service } from '../types';

const services: Service[] = [
  {
    id: '1',
    title: 'Trasporti Eccezionali',
    description: 'Gestione di carichi fuori sagoma e pesanti con permessi speciali e scorta tecnica in tutta Europa.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
      </svg>
    ),
    imageUrl: 'https://picsum.photos/seed/transport/600/400'
  },
  {
    id: '2',
    title: 'Autogrù e Sollevamento',
    description: 'Noleggio autogrù con operatore certificato per sollevamenti industriali, montaggi e posizionamenti di precisione.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
      </svg>
    ),
    imageUrl: 'https://picsum.photos/seed/crane/600/400'
  },
  {
    id: '3',
    title: 'Logistica Nautica',
    description: 'Specializzati nel trasporto e movimentazione di yacht, barche a vela e componenti nautici di grandi dimensioni.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
      </svg>
    ),
    imageUrl: 'https://picsum.photos/seed/boat/600/400'
  },
  {
    id: '4',
    title: 'Montaggi Industriali',
    description: 'Servizio chiavi in mano per lo smantellamento e il rimontaggio di macchinari industriali e intere linee di produzione.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
      </svg>
    ),
    imageUrl: 'https://picsum.photos/seed/factory/600/400'
  }
];

const Services: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-orange-600 font-bold uppercase tracking-widest text-sm mb-2">Cosa facciamo</h2>
        <h3 className="text-4xl md:text-5xl font-black text-gray-900 uppercase italic">Servizi di <span className="text-orange-600 underline decoration-gray-900 decoration-8">Punta</span></h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {services.map((service) => (
          <div key={service.id} className="group relative bg-gray-50 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all border border-gray-100 flex flex-col">
            <div className="relative h-48 overflow-hidden">
              <img 
                src={service.imageUrl} 
                alt={service.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gray-900/40 group-hover:bg-gray-900/20 transition-colors"></div>
              <div className="absolute bottom-4 left-4 bg-orange-600 text-white p-3 rounded-lg shadow-lg">
                {service.icon}
              </div>
            </div>
            
            <div className="p-6 flex-grow">
              <h4 className="text-xl font-bold mb-3 uppercase tracking-tight group-hover:text-orange-600 transition-colors">{service.title}</h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {service.description}
              </p>
            </div>
            
            <div className="px-6 pb-6 mt-auto">
              <button className="text-orange-600 font-bold text-sm uppercase flex items-center group-hover:translate-x-2 transition-transform">
                Scopri di più
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
